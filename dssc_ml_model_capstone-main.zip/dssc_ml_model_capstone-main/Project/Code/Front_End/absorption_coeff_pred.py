import pandas as pd
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from pymatgen.core.composition import Composition
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
import random
import math
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import PLSRegression
from sklearn.svm import SVR

# Import data into a dataframe
df_materials = pd.read_csv('df_materials_absorption.csv')

# Calculate the absorption coefficient and drop the original dielectric constant column
df_materials['Absorption_Coeff'] = ((2 * math.sqrt(2) * math.pi) / (600e-5)) * df_materials['Dielectric_List']
df_materials = df_materials.drop('Dielectric_List', axis=1)

# Initialize the dictionary with elements
elements_data = {
    'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [2], 'F': [0], 'Ne': [0],
    'Na': [0], 'Mg': [0], 'Al': [0], 'Si': [0], 'P': [0], 'S': [0], 'Cl': [0], 'Ar': [0], 'K': [0], 'Ca': [0],
    'Sc': [0], 'Ti': [1], 'V': [0], 'Cr': [0], 'Mn': [0], 'Fe': [0], 'Co': [0], 'Ni': [0], 'Cu': [0], 'Zn': [0],
    'Ga': [0], 'Ge': [0], 'As': [0], 'Se': [0], 'Br': [0], 'Kr': [0], 'Rb': [0], 'Sr': [0], 'Y': [0], 'Zr': [0],
    'Nb': [0], 'Mo': [0], 'Tc': [0], 'Ru': [0], 'Rh': [0], 'Pd': [0], 'Ag': [0], 'Cd': [0], 'In': [0], 'Sn': [0],
    'Sb': [0], 'Te': [0], 'I': [0], 'Xe': [0], 'Cs': [0], 'Ba': [0], 'La': [0], 'Ce': [0], 'Pr': [0], 'Nd': [0],
    'Pm': [0], 'Sm': [0], 'Eu': [0], 'Gd': [0], 'Tb': [0], 'Dy': [0], 'Ho': [0], 'Er': [0], 'Tm': [0], 'Yb': [0],
    'Lu': [0], 'Hf': [0], 'Ta': [0], 'W': [0], 'Re': [0], 'Os': [0], 'Ir': [0], 'Pt': [0], 'Au': [0], 'Hg': [0],
    'Tl': [0], 'Pb': [0], 'Bi': [0], 'Po': [0], 'At': [0], 'Rn': [0], 'Fr': [0], 'Ra': [0], 'Ac': [0], 'Th': [0],
    'Pa': [0], 'U': [0], 'Np': [0], 'Pu': [0], 'Am': [0], 'Cm': [0], 'Bk': [0], 'Cf': [0], 'Es': [0], 'Fm': [0],
    'Md': [0], 'No': [0], 'Lr': [0], 'Rf': [0], 'Db': [0], 'Sg': [0], 'Bh': [0], 'Hs': [0], 'Mt': [0], 'Ds': [0],
    'Rg': [0], 'Cn': [0], 'Nh': [0], 'Fl': [0], 'Mc': [0], 'Lv': [0], 'Ts': [0], 'Og': [0]
}

def lin_reg(X_train, y_train):
    """
    Function to create and train a linear regression model.

    Parameters:
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - lin_reg_model: Trained linear regression model
    - scaled: Boolean indicating whether the features are scaled (False for linear regression)
    - scaler: Scaler object (not used in linear regression)
    """
    # Create a linear regression model
    lin_reg_model = LinearRegression()

    # Train the model
    lin_reg_model.fit(X_train, y_train)

    # Indicate that features are not scaled
    scaled = False

    # No scaler used in linear regression
    scaler = 0

    # Returns the dielectric constant
    return lin_reg_model, scaled, scaler

def knn(X_train, y_train):
    """
    Function to create and train a k-Nearest Neighbors regression model.

    Parameters:
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - knn_model: Trained k-Nearest Neighbors regression model
    - scaled: Boolean indicating whether the features are scaled
    - scaler: Scaler object used for scaling the features
    """
    # Create a StandardScaler
    scaler = StandardScaler()

    # Scale the features
    X_train_scaled = scaler.fit_transform(X_train)

    # Create a k-Nearest Neighbors model
    knn_model = KNeighborsRegressor(n_neighbors=5)  # I will adjust the number of neighbors (n_neighbors) as needed to help with optimization. 

    # Train the model
    knn_model.fit(X_train_scaled, y_train)

    # Indicate that features are scaled
    scaled = True

    # Returns the dielectric constant
    return knn_model, scaled, scaler

def pls(X_train, y_train):
    """
    Function to create and train a Partial Least Squares regression model.

    Parameters:
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - pls_model: Trained Partial Least Squares regression model
    - scaled: Boolean indicating whether the features are scaled
    - scaler: Scaler object used for scaling the features
    """
    # Create a StandardScaler
    scaler = StandardScaler()

    # Scale the features
    X_train_scaled = scaler.fit_transform(X_train)

    # Create a PLS model with a specified number of components
    pls_model = PLSRegression(n_components=1)

    # Train the PLS model
    pls_model.fit(X_train_scaled, y_train)

    # Indicate that features are scaled
    scaled = True

    return pls_model, scaled, scaler

def svm(X_train, y_train):
    """
    Function to create and train a Support Vector Machine regression model.

    Parameters:
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - svm_model: Trained Support Vector Machine regression model
    - scaled: Boolean indicating whether the features are scaled
    - scaler: Scaler object used for scaling the features
    """
    # Create a StandardScaler
    scaler = StandardScaler()

    # Scale the features
    X_train_scaled = scaler.fit_transform(X_train)

    # Create an SVR model
    svm_model = SVR(kernel='poly', C=1000)  

    # Train the SVM model
    svm_model.fit(X_train_scaled, y_train)

    # Indicate that features are scaled
    scaled = True

    return svm_model, scaled, scaler
