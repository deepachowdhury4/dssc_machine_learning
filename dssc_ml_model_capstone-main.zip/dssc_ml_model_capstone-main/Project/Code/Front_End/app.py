   
import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from absorption_coeff_pred import lin_reg, knn, pls, svm
from pymatgen.core.composition import Composition
from sklearn.svm import SVR
from sklearn.cross_decomposition import PLSRegression
from sklearn.preprocessing import StandardScaler
import math
from scipy.integrate import simps
from PIL import Image
import warnings
from collections import Counter
import sys
warnings.filterwarnings("ignore")

failed_error = 'False' #variable to track if any errors occur

# Function to generate a sample plot based on the entered compound and ML model
def find_model(model_type_func, X_train, y_train):
    """
    Function to find and return the ML model, whether the features are scaled, and the scaler.

    Parameters:
    - model_type_func: Selected ML model type
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - model_testing: Trained ML model
    - scalar_true: Boolean indicating whether the features are scaled
    - scaler: Scaler object
    """
    if model_type_func == 'Linear Regression':
        model_testing, scalar_true, scaler = lin_reg(X_train, y_train)  
    elif model_type_func == 'KNN':
        model_testing, scalar_true, scaler = knn(X_train, y_train)  
    elif model_type_func == 'PLS':
        model_testing, scalar_true, scaler = pls(X_train, y_train)  
    elif model_type_func == 'SVM':
        model_testing, scalar_true, scaler = svm(X_train, y_train)  
    else:
        st.error("Invalid ML model type selected.")

    return model_testing, scalar_true, scaler

#Function that generates plots based on values predicted from user input and ML Model
def generate_plot(compound_input, metal_oxide, model_type, current, voltage, dopant_percent, perc_metal_oxide):
    """
    Function to generate and return a plot.

    Parameters:
    - compound_input: Entered compound or element
    - model_type: ML model type
    - current: Current values
    - voltage: Voltage values

    Returns:
    - plt: Plot object
    """
    plt.plot(voltage, current)

    #find the short circuit density and open circuit voltage
    # slope, y_intercept = np.polyfit(voltage, current, 1)
    # x_intercept = -y_intercept/slope
    x_intercept = 0
    y_intercept = 0
    
    for x, y in zip(voltage, current):
        if x > -0.1 and x < 0.1:
            y_intercept = y
        if y > -0.01 and y < 0.01:
            x_intercept = x
    short_density = y_intercept
    open_voltage = x_intercept
    plt.title(f'I-V Curve of {dopant_percent}% {compound_input} - {perc_metal_oxide}% {metal_oxide} SCO Using {model_type} ML Model')
    plt.xlabel('Voltage (V)')
    plt.ylabel('Current (mA/cm^2)')

    return plt, voltage, current, short_density, open_voltage

#Calculates I-V values and other important values for PCE calculations
def pce_calc(prediction, length):
    """
    Function to calculate PCE, J_SC, V_OC, and J for a given prediction.

    Parameters:
    - prediction: Predicted value

    Returns:
    - pce: Calculated PCE
    - j: Current density values
    - X_y_values: Voltage values
    """
    # Constants
    q = 1.602e-19
    phi = 10e17
    L = 2.2361e-3
    d = float(length)
    k = 1.381e-23
    T = 300
    m = 4.5 
    D = 3.4e-4
    n_0 = 10e16
    light_intensity = 100  # mW/cm^2
    prediction = float(prediction)

    # Generate X_y values from 0 to 0.85 V in increments of 0.0001
    X_y_values = np.arange(0, 0.85, 0.0001)

    # Calculate J_SC for the given prediction
    j_sc = float((q * phi * L * prediction) / (1 - (L ** 2 * prediction ** 2))) * (
            -L * prediction + np.tanh(d / L) + ((L * prediction * np.exp(-d * prediction)) / np.cosh(d / L)))
    
    # Calculate V_OC
    v_oc = ((k * T * m) / q) * np.log(((L * j_sc) / (q * D * n_0 * np.tanh(d / L))) + 1)

    # Calculate J for the entire X_y_values range
    j = 3.25*(3.25 + j_sc - ((q * D * n_0 / L) * np.tanh(d / L)) * (np.exp((q * X_y_values) / (k * T * m)) - 1))

    # Initialize variables to store the maximum area and corresponding x, y values
    max_area = 0
    max_x = 0
    max_y = 0

    # Iterate through different intervals
    for i in range(1, len(X_y_values)):
        # Calculate the current density for the current interval
        j_interval = j[:i]

        # Calculate the area under the curve for the current interval
        area = simps(j_interval, X_y_values[:i])

        # Update the maximum area and corresponding x, y values if the current area is greater, checking if less than Voc
        if area > max_area and max_x < v_oc:
            max_area = area
            max_x = X_y_values[i - 1]
            max_y = np.max(j_interval)

    # Calculate important values for PCE calculation
    max_power = (max_x * max_y)/1000 #Unit Correction
    ff = max_power/(v_oc*j_sc)*100 #Convert to Percent

    return j, X_y_values, max_power

# Streamlit app
image = Image.open('dssc.png')
st.title('Predicting Power Performance of Dye-Sensitized Solar Cells Using Machine Learning Techniques')
st.header("PCE Optimization in Dye-Sensitized Solar Cells through Photoanode Modifications")
st.subheader('Deepanjali Chowdhury, ECEN 403/404H Capstone Project, Section 971')

col1, col2 = st.columns(2)

with col1:
    st.caption("Howdy! I'm Deepanjali Chowdhury, a senior electrical engineering major at Texas A&M University. " +
           'My capstone project utilizes machine learning to determine the PCE of a DSSC through a simulation. ')
    st.caption('The following assumptions in the image to the right are made in this DSSC Configuration as seen in paper [2][3]. This simulation is adjusting the photoanode material for PCE Prediction.')
    st.caption('NOTE: There are multiple ML Models to try out in this simulation but our lab group is currently working to improve and optimize the KNN model for PCE Prediction. For more information, please check out the github page: https://github.tamu.edu/deepachowdhury/dssc_ml_model_capstone')  

with col2:
    st.image(image, caption='DSSC Configuration With Listed Assumptions [1]', width = 500)

#Get user input (Compound that User Enters)
compound_input = st.text_input("Enter a compound or element(e.g., H2O, Si, C) in X-Doped Metal Oxide: ")
# User Input for Percentage of Dopant  
percent_dopant_material = st.slider('Percentage of Dopant Material:', 0.0, 100.0, step = .5) 
percent_metal_oxide = 100-percent_dopant_material
metal_oxide_type = st.selectbox('Select Metal Oxide', ['TiO2', 'NiWO4', 'CoWO4', 'CoSn(OH)6', 'Al2O3'])

st.divider()

#Area & Hole/Electron Mobilities Information Input:
cola, colb = st.columns(2)
if "visibility" not in st.session_state:
    st.session_state.visibility = "visible"
    st.session_state.disabled = False

# Columna section for input related to the semi-conducting oxide layer
with cola:
    # Display information about the input field
    st.markdown('Area of Semi-Conducting Oxide Layer (Optional)')
    # Text input field for the length of the SCO layer
    length_area = st.text_input("Enter the Length of the SCO Layer (cm):",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        placeholder='Note: Default is 1 cm',
    )
    # Check if the length input is empty
    if len(length_area) < 1:
        length_area = 1  # Set default value to 1 cm if input is empty
    else:
        try:
            length_area = float(length_area) / 100  # Convert input to float and adjust units if necessary
        except:
            pass
            failed_error = 'True'  # Set error flag if input cannot be converted to float
            st.error('User Input Error: Please input a numerical value for length of the SCO.')

    # Text input field for the width of the SCO layer
    width_area = st.text_input("Enter the Width of the SCO Layer (cm):",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        placeholder='Note: Default is 1 cm',
    )
    # Check if the width input is empty
    if len(width_area) < 1:
        width_area = 1  # Set default value to 1 cm if input is empty
    else:
        try:
            width_area = float(width_area) / 100  # Convert input to float and adjust units if necessary
        except:
            pass
            failed_error = 'True'  # Set error flag if input cannot be converted to float
            st.error('User Input Error: Please input a numerical value for width of the SCO.')

# Columnb section for input related to hole and electron mobilities
with colb: 
    # Display information about the input fields
    st.markdown('Hole and Electron Mobilities (Optional)')
    # Text input field for electron mobility
    electron_mobility = st.text_input("Enter the Electron Mobility: ",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        placeholder='Note: Default is Not Calculated',
    )
    # Check if electron mobility input is empty
    if len(electron_mobility) < 1:
        electron_mobility = 'Not Calculated'  # Set default value if input is empty
    else:
        try:
            electron_mobility = float(electron_mobility)  # Convert input to float
        except:
            pass
            failed_error = 'True'  # Set error flag if input cannot be converted to float
            st.error('User Input Error: Please input a numerical value for the Electron Mobility of the cell.')
        electron_mobility = float(electron_mobility)  # Convert input to float

    # Text input field for hole mobility
    hole_mobility = st.text_input("Enter the Hole Mobility of the SCO Layer: ",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        placeholder='Note: Default is Not Calculated',
    )
    # Check if hole mobility input is empty
    if len(hole_mobility) < 1:
        hole_mobility = 'Not Calculated'  # Set default value if input is empty
    else:
        try:
            hole_mobility = float(hole_mobility)  # Convert input to float
        except:
            pass
            failed_error = 'True'  # Set error flag if input cannot be converted to float
            st.error('User Input Error: Please input a numerical value for the Hole Mobility of the cell.')

st.divider()

# Dropdown menu to select ML model type, edit to only be KNN? 
model_type_input = st.selectbox('Select ML Model Type', ['Linear Regression', 'KNN', 'PLS', 'SVM'])
save_data = st.selectbox('Would you like to save your data to a .csv file?', ['Yes', 'No'])

# Button to submit entries
if st.button('Submit'):
    # Split data into features (X) and target variable (y)
    df_materials_absorp = pd.read_csv('df_materials_absorption.csv')
    total_count_metal_oxide = 0
    total_count = 0
    df_materials_absorp['Absorption_Coeff'] = ((2 * math.sqrt(2)*math.pi) / (600e-5)) * df_materials_absorp['Dielectric_List'] 
    df_materials_absorp = df_materials_absorp.drop('Dielectric_List', axis=1)
    X_train_absorp = df_materials_absorp.dropna().drop(['Compound_List', 'Absorption_Coeff'], axis=1)
    y_train_absorp = df_materials_absorp.dropna()['Absorption_Coeff']

    # Generate and display the plot
    model_type, scaled_true, scaler = find_model(model_type_input, X_train_absorp, y_train_absorp)
    elements_data = {
        'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [0], 'F': [0], 'Ne': [0],
        'Na': [0], 'Mg': [0], 'Al': [0], 'Si': [0], 'P': [0], 'S': [0], 'Cl': [0], 'Ar': [0], 'K': [0], 'Ca': [0],
        'Sc': [0], 'Ti': [0], 'V': [0], 'Cr': [0], 'Mn': [0], 'Fe': [0], 'Co': [0], 'Ni': [0], 'Cu': [0], 'Zn': [0],
        'Ga': [0], 'Ge': [0], 'As': [0], 'Se': [0], 'Br': [0], 'Kr': [0], 'Rb': [0], 'Sr': [0], 'Y': [0], 'Zr': [0],
        'Nb': [0], 'Mo': [0], 'Tc': [0], 'Ru': [0], 'Rh': [0], 'Pd': [0], 'Ag': [0], 'Cd': [0], 'In': [0], 'Sn': [0],
        'Sb': [0], 'Te': [0], 'I': [0], 'Xe': [0], 'Cs': [0], 'Ba': [0], 'La': [0], 'Ce': [0], 'Pr': [0], 'Nd': [0],
        'Pm': [0], 'Sm': [0], 'Eu': [0], 'Gd': [0], 'Tb': [0], 'Dy': [0], 'Ho': [0], 'Er': [0], 'Tm': [0], 'Yb': [0],
        'Lu': [0], 'Hf': [0], 'Ta': [0], 'W': [0], 'Re': [0], 'Os': [0], 'Ir': [0], 'Pt': [0], 'Au': [0], 'Hg': [0],
        'Tl': [0], 'Pb': [0], 'Bi': [0], 'Po': [0], 'At': [0], 'Rn': [0], 'Fr': [0], 'Ra': [0], 'Ac': [0], 'Th': [0],
        'Pa': [0], 'U': [0], 'Np': [0], 'Pu': [0], 'Am': [0], 'Cm': [0], 'Bk': [0], 'Cf': [0], 'Es': [0], 'Fm': [0],
        'Md': [0], 'No': [0], 'Lr': [0], 'Rf': [0], 'Db': [0], 'Sg': [0], 'Bh': [0], 'Hs': [0], 'Mt': [0], 'Ds': [0],
        'Rg': [0], 'Cn': [0], 'Nh': [0], 'Fl': [0], 'Mc': [0], 'Lv': [0], 'Ts': [0], 'Og': [0]
    }

    try:
        # Get a dictionary of element counts in the metal oxide compound
        # Total count of all elements in the metal oxide compound
        for element, count in Composition(metal_oxide_type).get_el_amt_dict().items():
            total_count_metal_oxide +=count
    
        #Percentage to Element Conversion for Metal Oxide
        for element, count in Composition(metal_oxide_type).get_el_amt_dict().items():
            elements_data[element] = [round(count*(percent_metal_oxide/total_count_metal_oxide),0)]

        # Get a dictionary of element counts in the compound
        # Total count of all elements in the compound
        for element, count in Composition(compound_input).get_el_amt_dict().items():
            total_count +=count

        #Percentage to Element Conversion for User Input
        for element, count in Composition(compound_input).get_el_amt_dict().items():
            elements_data[element] = round(elements_data[element][0]+count*(percent_dopant_material/total_count),0)
        
        # Debugging
        # for index, row in element_tio2_data.iterrows():
        #     for column, value in row.items():
        #         print(f"Value {column}: {value}")
            
    except:
        pass
        failed_error = 'True'
        st.error('Error: User input element does not exist. Please correct the input to a valid element and click submit again to rerun the model.')
        
    element_tio2_data = pd.DataFrame(elements_data)

    if failed_error == 'False':

        # Check if scaling is required and scale the data accordingly
        if scaled_true:
            element_tio2_data_scaled = scaler.transform(element_tio2_data)  # Scale only for KNN and PLS models
        else:
            element_tio2_data_scaled = element_tio2_data

        # Make predictions using the trained model
        prediction_linear = model_type.predict(element_tio2_data_scaled)

        # Calculate PCE, generate the plot, and display the results
        current_vals, voltage_vals, p_max = pce_calc(prediction_linear, length_area)

        #Recombination Calculation
        k = 1.381e-23 #Boltzman Constant
        if hole_mobility == 'Not Calculated' or electron_mobility == 'Not Calculated':
            recomb_var = 'Not Calculated'
        else:
            recomb_var = float(k*(prediction_linear[0]/100)*hole_mobility*electron_mobility)

        plot,volt_vals,curr_vals, short_current_density, open_circuit_voltage = generate_plot(compound_input, metal_oxide_type, model_type_input, current_vals, voltage_vals, percent_dopant_material, percent_metal_oxide)
        
        fillf = p_max/(open_circuit_voltage*short_current_density)*100000 #Unit Conversion and Percent Conversion

        pce_prediction = (open_circuit_voltage*short_current_density*fillf)/100 #Percent Conversion, Units are mW/cm^2

        #Conductivity & Impendence Calculations
        impedence = (open_circuit_voltage/short_current_density)*((length_area*width_area)/length_area) # Units are cm
        conductivity = 1/impedence

        st.pyplot(plot)

        # Bandgap Prediction
        df_materials_bandgap = pd.read_csv('df_materials_bandgap.csv')
        X_train_bandgap = df_materials_bandgap.dropna().drop(['Formula', 'Bandgap'], axis=1)
        y_train_bandgap = df_materials_bandgap.dropna()['Bandgap']

        # Train the model for bandgap prediction and make predictions
        model_type, scaled_true, scaler = find_model(model_type_input, X_train_bandgap, y_train_bandgap)
    
        # Make predictions for bandgap using the trained model
        prediction_bandgap = model_type.predict(element_tio2_data_scaled)

        # Adjust the prediction based on the model type
        if model_type_input == 'KNN':
            prediction_bandgap[0] = prediction_bandgap[0]*6.4
        else:
            prediction_bandgap[0] = 0

        #Output of all Text Features onto Front End
        colx, coly =st.columns(2)

        with colx:
            st.write(f'PCE Numeric Output: {round(pce_prediction , 5)} %')
            st.write(f'Fill Factor: {round(float(fillf),5)} %')
            
            
        with coly: 
            st.write(f'Open-Circuit Voltage: {round(open_circuit_voltage,5)} V')
            st.write(f'Short-Circuit Current Density: {round(short_current_density,5)} mA/cm^2')
            

        st.divider()
        cola, colb = st.columns(2)

        with cola:
            if recomb_var == 'Not Calculated':
                st.write('Recombination Rate: Not Calculated')
            else:
                st.write(f'Recombination Rate: {recomb_var:.3e}')

            
            st.write(f'Prediction of Absorption Coefficient: {round(prediction_linear[0], 2)} 1/cm')
            st.caption('*Note: Absorbance + Transmittance = 1*')

        with colb:
            st.write(f'Electron Conductivity: {round(conductivity,5)} S/cm')
            st.write(f'Electron Impedence: {round(impedence,5)} Ω*cm')
            # Display the bandgap prediction
            st.write(f'Bandgap Prediction: {round(prediction_bandgap[0], 5)} eV')
            st.write(f'Max Power:  {round(p_max*1000, 5)} mW/cm^2')

        if save_data == 'Yes':
            #Save Data to .csv File
            data = {'Voltage (V)': volt_vals, 'Current (mA)': curr_vals}
            df = pd.DataFrame(data)
            # Save DataFrame to CSV
            df.to_csv(f'{metal_oxide_type}_{percent_metal_oxide}_{compound_input}_{percent_dopant_material}_iv_curve_data.csv', index=False)
            st.write(f'{metal_oxide_type}_{percent_metal_oxide}_{compound_input}_{percent_dopant_material}_iv_curve_data.csv Saved to Computer!')

        # Display references
        st.divider()
        st.caption('References:')
        st.caption('[1] A. Sarkar, Amit K. Chakraborty, S. Bera, NiS/rGO nanohybrid: An excellent counter electrode for dye sensitized solar cell, Solar Energy Materials and Solar Cells,Volume 182,2018,Pages 314-320, ISSN 0927-0248, https://doi.org/10.1016/j.solmat.2018.03.026')
        st.caption('[2] El Tayyan, Ahmed. (2011). Dye sensitized solar cell: Parameters calculation and model integration. Journal of Electron Devices. 11. 616-624.')
        st.caption('[3] E Supriyanto et al 2019 IOP Conf. Ser.: Mater. Sci. Eng. 515 012048')









