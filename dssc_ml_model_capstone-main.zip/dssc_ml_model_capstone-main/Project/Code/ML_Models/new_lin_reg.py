# Import necessary libraries
import pandas as pd
from sklearn.linear_model import LinearRegression
from pymatgen.core.composition import Composition
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import math
from sklearn.metrics import mean_absolute_error, explained_variance_score

# Example DataFrame
data = {
    'Compound': ['BiTeCl', 'SCl', 'KZn4(SbO4)3', 'NaSr3SbO6', 'KLiSe', 'LiYS2', 'CaTaAlO5', 'Element+TiO2'],
    # ... (rest of the data)
    'AbsorbanceCoefficient': [21.52106861, 3.218927504, 10.73760413, 13.6244769, 8.849830877, 21.16426674, 28.98567947, None]
}

# Create DataFrame
df = pd.DataFrame(data)

# Read data from CSV file
df_materials = pd.read_csv('df_materials_updated.csv')

# Split data into features (X) and target variable (y)
X_train = df_materials.dropna().drop(['Compound_List', 'Dielectric_List'], axis=1)
y_train = df_materials.dropna()['Dielectric_List']

# Create a linear regression model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Initialize the dictionary with elements
elements_data = {
    'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [2], 'F': [0], 'Ne': [0],
    # ... (rest of the elements)
}

# Get user input for compound or elements
user_input = input("Enter 'compound' or 'elements': ")

if user_input.lower() == 'compound':
    # Get user input for a compound
    compound_input = input("Enter a compound (e.g., H2O): ")
    prediction_input = compound_input
    
    # Parse the compound and update the dictionary with element counts
    for element, count in Composition(compound_input).get_el_amt_dict().items():
        elements_data[element][0] = count

elif user_input.lower() == 'elements':
    # Get user input for a list of elements
    elements_input = input("Enter a comma-separated list of elements: ")
    prediction_input = elements_input
    
    # Split the input string into a list
    elements_list = elements_input.split(',')
    
    # Update the dictionary with element counts
    for element in elements_list:
        if element in elements_data:
            elements_data[element][0] += 1

else:
    print("Invalid input. Please enter 'compound' or 'elements'.")

# Display the updated dictionary
# print("Updated Elements Data:")
# for element, value in elements_data.items():
#     print(f"{element}: {value}")


# Make predictions for Element+TiO2
element_tio2_data = pd.DataFrame(elements_data)

prediction_linear = model.predict(element_tio2_data)

print(f"Predicted Absorbance Coefficient for {prediction_input} + TiO2 (Linear Regression): {prediction_linear[0]}")



# Scatter plot for Linear Regression
# Plotting
# prediction = model.predict(element_tio2_data)
# plt.scatter(X_train, y_train, color='blue', label='Actual Data')  # Scatter plot of actual data
# plt.scatter([1], prediction, color='red', label='Predicted Value')  # Scatter plot of predicted value
# plt.plot(X_train['Ti'], model.predict(X_train), color='green', linewidth=2, label='Linear Regression Model')  # Line plot of linear regression model

# plt.title('Linear Regression Model')
# plt.xlabel('Titanium (Ti) Count')
# plt.ylabel('Dielectric Constant')
# plt.legend()
# plt.show()

y_pred_linear = model.predict(X_train)
y_true = df_materials.dropna()['Dielectric_List']

for i in range(len(y_true)):
    y_true[i] =  ((2*math.pi*math.sqrt(2))/600)*math.sqrt(y_true[i])
    y_pred_linear[i] =  ((2*math.pi*math.sqrt(2))/600)*math.sqrt(abs(y_pred_linear[i]))


# # Residual plot
# residuals_linear = y_true - y_pred_linear

# plt.figure(figsize=(8, 6))
# plt.scatter(y_pred_linear, residuals_linear, color='blue', label='Residuals')
# plt.axhline(y=0, color='red', linestyle='--', label='Zero Residuals Line')
# plt.title('Residual Plot - Linear Regression')
# plt.xlabel('Predicted Absorbance Coefficient')
# plt.ylabel('Residuals')
# plt.legend()
# plt.show()

# Scatter plot for Linear Regression
plt.figure(figsize=(8, 6))
sns.regplot(x=.75+y_true/100, y=.75+y_pred_linear/100, color='red', label='Linear Regression')
plt.title('Linear Regression - Actual vs Predicted')
plt.xlabel('Actual Absorbance Coefficient')
plt.ylabel('Predicted Absorbance Coefficient')
plt.xlim(0.75, .765)
plt.ylim(0.75, 0.765) 
plt.legend()
plt.show()

# Evaluate the model
y_true = df_materials.dropna()['Dielectric_List']
y_pred = model.predict(X_train)
# Evaluate the Linear Regression model
y_pred_linear = model.predict(X_train)
mse_linear = mean_squared_error(y_true, y_pred_linear)
r_squared_linear = r2_score(y_true, y_pred_linear)

mae = mean_absolute_error(y_true, y_pred_linear)

rmse = np.sqrt(mean_squared_error(y_true, y_pred_linear))
ev = explained_variance_score(y_true, y_pred_linear)

mape = np.mean(np.abs((y_true - y_pred_linear) / y_true)) * 100

print(f"Root Mean Squared Error: {rmse}")
print(f"Mean Squared Error: {mse_linear}")
print(f"Mean Absolute Error: {mae}")
print(f"Mean Absolute Percentage Error: {mape}")
print(f"Explained Variance Score: {ev}")
print(f"R-squared: {r_squared_linear}")
