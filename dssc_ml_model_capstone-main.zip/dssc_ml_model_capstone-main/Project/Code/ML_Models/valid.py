#Import necessary packages
import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from absorption_coeff_pred import lin_reg, knn, pls, svm
from pymatgen.core.composition import Composition
from sklearn.svm import SVR
from sklearn.cross_decomposition import PLSRegression
from sklearn.preprocessing import StandardScaler
import math
from scipy.integrate import simps
from PIL import Image

def find_model(model_type_func, X_train, y_train):
    """
    Function to find and return the ML model, whether the features are scaled, and the scaler.

    Parameters:
    - model_type_func: Selected ML model type
    - X_train: Features for training
    - y_train: Target variable for training

    Returns:
    - model_testing: Trained ML model
    - scalar_true: Boolean indicating whether the features are scaled
    - scaler: Scaler object
    """
    if model_type_func == 'Linear Regression':
        model_testing, scalar_true, scaler = lin_reg(X_train, y_train)  
    elif model_type_func == 'KNN':
        model_testing, scalar_true, scaler = knn(X_train, y_train)  
    elif model_type_func == 'PLS':
        model_testing, scalar_true, scaler = pls(X_train, y_train)  
    elif model_type_func == 'SVM':
        model_testing, scalar_true, scaler = svm(X_train, y_train)  
    else:
        return ("Invalid ML model type selected.")

    return model_testing, scalar_true, scaler

def generate_plot(compound_input, model_type, current, voltage):
    """
    Function to generate and return a plot.

    Parameters:
    - compound_input: Entered compound or element
    - model_type: ML model type
    - current: Current values
    - voltage: Voltage values

    Returns:
    - plt: Plot object
    """
    plt.plot(voltage, current)
    plt.title(f'I-V Curve of {compound_input} - Doped TiO2 Using {model_type} ML Model')
    plt.xlabel('Voltage (V)')
    plt.ylabel('Current (mA)')
    return plt

def pce_calc(prediction):
    """
    Function to calculate PCE, J_SC, V_OC, and J for a given prediction.

    Parameters:
    - prediction: Predicted value

    Returns:
    - pce: Calculated PCE
    - j: Current density values
    - X_y_values: Voltage values
    """
    # Constants
    q = 1.602e-19
    phi = 10e17
    L = 2.2361e-3
    d = 5e-4
    k = 1.381e-23
    T = 300
    m = 4.5
    D = 3.4e-4
    n_0 = 10e16
    light_intensity = 136.1  # mW/cm^2

    # Generate X_y values from 0 to 0.75 V in increments of 0.0001
    X_y_values = np.arange(0, 0.85, 0.0001)

    # Calculate J_SC for the given prediction
    j_sc = ((q * phi * L * prediction) / (1 - (L ** 2 * prediction ** 2))) * (
            -L * prediction + np.tanh(d / L) + ((L * prediction * np.exp(-d * prediction)) / np.cosh(d / L)))

    # Calculate V_OC
    v_oc = ((k * T * m) / q) * np.log(((L * j_sc) / (q * D * n_0 * np.tanh(d / L))) + 1)

    # Calculate J for the entire X_y_values range
    j = 2.5 + j_sc - ((q * D * n_0 / L) * np.tanh(d / L)) * (np.exp((q * X_y_values) / (k * T * m)) - 1)

    # Initialize variables to store the maximum area and corresponding x, y values
    max_area = 0
    max_x = 0
    max_y = 0

    # Iterate through different intervals
    for i in range(1, len(X_y_values)):
        # Calculate the current density for the current interval
        j_interval = j[:i]

        # Calculate the area under the curve for the current interval
        area = simps(j_interval, X_y_values[:i])

        # Update the maximum area and corresponding x, y values if the current area is greater
        if area > max_area:
            max_area = area
            max_x = X_y_values[i - 1]
            max_y = np.max(j_interval)

    # Calculate PCE
    max_power = (max_x * max_y)
    pce = (max_power) / light_intensity

    return pce * 10e17, j, X_y_values


# Split data into features (X) and target variable (y)
df_materials_absorp = pd.read_csv('df_materials_absorption.csv')
df_materials_absorp['Absorption_Coeff'] = ((2 * math.sqrt(2)*math.pi) / (600e-5)) * df_materials_absorp['Dielectric_List'] 
df_materials_absorp = df_materials_absorp.drop('Dielectric_List', axis=1)
X_train_absorp = df_materials_absorp.dropna().drop(['Compound_List', 'Absorption_Coeff'], axis=1)
y_train_absorp = df_materials_absorp.dropna()['Absorption_Coeff']

df_experiments = pd.read_csv('tio2_testing_experimental.csv')
df_experiments = df_experiments.fillna('')
compound_list_experimental = df_experiments.iloc[:, 1].tolist()
new_dataframe = pd.DataFrame()
for model_type_input in ['Linear Regression', 'KNN', 'PLS']:
    # Initialize an empty DataFrame
    pce_list = []
    bandgap_list = []
    for compound_input in compound_list_experimental: 
        # Generate and display the plot
        model_type, scaled_true, scaler = find_model(model_type_input, X_train_absorp, y_train_absorp)
        elements_data = {
            'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [2], 'F': [0], 'Ne': [0],
            'Na': [0], 'Mg': [0], 'Al': [0], 'Si': [0], 'P': [0], 'S': [0], 'Cl': [0], 'Ar': [0], 'K': [0], 'Ca': [0],
            'Sc': [0], 'Ti': [1], 'V': [0], 'Cr': [0], 'Mn': [0], 'Fe': [0], 'Co': [0], 'Ni': [0], 'Cu': [0], 'Zn': [0],
            'Ga': [0], 'Ge': [0], 'As': [0], 'Se': [0], 'Br': [0], 'Kr': [0], 'Rb': [0], 'Sr': [0], 'Y': [0], 'Zr': [0],
            'Nb': [0], 'Mo': [0], 'Tc': [0], 'Ru': [0], 'Rh': [0], 'Pd': [0], 'Ag': [0], 'Cd': [0], 'In': [0], 'Sn': [0],
            'Sb': [0], 'Te': [0], 'I': [0], 'Xe': [0], 'Cs': [0], 'Ba': [0], 'La': [0], 'Ce': [0], 'Pr': [0], 'Nd': [0],
            'Pm': [0], 'Sm': [0], 'Eu': [0], 'Gd': [0], 'Tb': [0], 'Dy': [0], 'Ho': [0], 'Er': [0], 'Tm': [0], 'Yb': [0],
            'Lu': [0], 'Hf': [0], 'Ta': [0], 'W': [0], 'Re': [0], 'Os': [0], 'Ir': [0], 'Pt': [0], 'Au': [0], 'Hg': [0],
            'Tl': [0], 'Pb': [0], 'Bi': [0], 'Po': [0], 'At': [0], 'Rn': [0], 'Fr': [0], 'Ra': [0], 'Ac': [0], 'Th': [0],
            'Pa': [0], 'U': [0], 'Np': [0], 'Pu': [0], 'Am': [0], 'Cm': [0], 'Bk': [0], 'Cf': [0], 'Es': [0], 'Fm': [0],
            'Md': [0], 'No': [0], 'Lr': [0], 'Rf': [0], 'Db': [0], 'Sg': [0], 'Bh': [0], 'Hs': [0], 'Mt': [0], 'Ds': [0],
            'Rg': [0], 'Cn': [0], 'Nh': [0], 'Fl': [0], 'Mc': [0], 'Lv': [0], 'Ts': [0], 'Og': [0]
        }

        # Extracting element counts from the compound and creating a DataFrame
        for element, count in Composition(compound_input).get_el_amt_dict().items():
            elements_data[element] = count
        element_tio2_data = pd.DataFrame(elements_data)

        # Check if scaling is required and scale the data accordingly
        if scaled_true:
            element_tio2_data_scaled = scaler.transform(element_tio2_data)  # Scale only for KNN and PLS models
        else:
            element_tio2_data_scaled = element_tio2_data

        # Make predictions using the trained model
        prediction_linear = model_type.predict(element_tio2_data_scaled)

        # Calculate PCE, generate the plot, and display the results
        pce_prediction, current, voltage = pce_calc(prediction_linear)

        pce = round(pce_prediction * 4.8 * 10e-17, 5)
        pce_list.append(pce)
        

        # Bandgap Prediction
        df_materials_bandgap = pd.read_csv('df_materials_bandgap.csv')
        X_train_bandgap = df_materials_bandgap.dropna().drop(['Formula', 'Bandgap'], axis=1)
        y_train_bandgap = df_materials_bandgap.dropna()['Bandgap']

        # Train the model for bandgap prediction and make predictions
        model_type, scaled_true, scaler = find_model(model_type_input, X_train_bandgap, y_train_bandgap)
        elements_data = {
            'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [2], 'F': [0], 'Ne': [0],
            'Na': [0], 'Mg': [0], 'Al': [0], 'Si': [0], 'P': [0], 'S': [0], 'Cl': [0], 'Ar': [0], 'K': [0], 'Ca': [0],
            'Sc': [0], 'Ti': [1], 'V': [0], 'Cr': [0], 'Mn': [0], 'Fe': [0], 'Co': [0], 'Ni': [0], 'Cu': [0], 'Zn': [0],
            'Ga': [0], 'Ge': [0], 'As': [0], 'Se': [0], 'Br': [0], 'Kr': [0], 'Rb': [0], 'Sr': [0], 'Y': [0], 'Zr': [0],
            'Nb': [0], 'Mo': [0], 'Tc': [0], 'Ru': [0], 'Rh': [0], 'Pd': [0], 'Ag': [0], 'Cd': [0], 'In': [0], 'Sn': [0],
            'Sb': [0], 'Te': [0], 'I': [0], 'Xe': [0], 'Cs': [0], 'Ba': [0], 'La': [0], 'Ce': [0], 'Pr': [0], 'Nd': [0],
            'Pm': [0], 'Sm': [0], 'Eu': [0], 'Gd': [0], 'Tb': [0], 'Dy': [0], 'Ho': [0], 'Er': [0], 'Tm': [0], 'Yb': [0],
            'Lu': [0], 'Hf': [0], 'Ta': [0], 'W': [0], 'Re': [0], 'Os': [0], 'Ir': [0], 'Pt': [0], 'Au': [0], 'Hg': [0],
            'Tl': [0], 'Pb': [0], 'Bi': [0], 'Po': [0], 'At': [0], 'Rn': [0], 'Fr': [0], 'Ra': [0], 'Ac': [0], 'Th': [0],
            'Pa': [0], 'U': [0], 'Np': [0], 'Pu': [0], 'Am': [0], 'Cm': [0], 'Bk': [0], 'Cf': [0], 'Es': [0], 'Fm': [0],
            'Md': [0], 'No': [0], 'Lr': [0], 'Rf': [0], 'Db': [0], 'Sg': [0], 'Bh': [0], 'Hs': [0], 'Mt': [0], 'Ds': [0],
            'Rg': [0], 'Cn': [0], 'Nh': [0], 'Fl': [0], 'Mc': [0], 'Lv': [0], 'Ts': [0], 'Og': [0]
        }

        for element, count in Composition(compound_input).get_el_amt_dict().items():
            elements_data[element] = count
        element_tio2_data = pd.DataFrame(elements_data)

        # Check if scaling is required and scale the data accordingly
        if scaled_true:
            element_tio2_data_scaled = scaler.transform(element_tio2_data)  # Scale only for KNN and PLS models
        else:
            element_tio2_data_scaled = element_tio2_data

        # Make predictions for bandgap using the trained model
        prediction_bandgap = model_type.predict(element_tio2_data_scaled)

        # Adjust the prediction based on the model type
        if model_type_input == 'KNN':
            prediction_bandgap[0] = prediction_bandgap[0] * 40
        else:
            prediction_bandgap[0] = prediction_bandgap[0] * 3.2

        # Display the bandgap prediction
        bandgap = round(prediction_bandgap[0], 5)

        bandgap_list.append(bandgap)
    
    pce_name = model_type_input+'_PCE_Prediction'
    bandgap_name = model_type_input+'_Bandgap_Prediction'
    new_dataframe[pce_name] = pce_list
    new_dataframe[bandgap_name] = bandgap_list
    print("Upload comeplete for "+model_type_input)



new_dataframe.to_csv('predictions.csv')