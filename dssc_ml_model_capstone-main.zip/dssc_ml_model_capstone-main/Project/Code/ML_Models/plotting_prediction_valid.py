# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt

# Read the CSV file into a pandas DataFrame
df = pd.read_csv('predictions.csv')

# Split the DataFrame into two parts
df1 = df[0:12]
df2 = df[12:]

# Define a function to plot the data
def plot_it2(df, num):
    # Extract relevant columns from the DataFrame
    elements = df.Elements.astype(str)
    actual = df.PCE_Experimental.astype(float)

    models = df.iloc[:, 2:].astype(float)
    model1 = models.iloc[:, 0]
    model2 = models.iloc[:, 1]
    model3 = models.iloc[:, 2]
    model4 = models.iloc[:, 3]

    # Create a color map for differentiating models
    purps = plt.get_cmap('Set1')

    # Create a figure and axis for the plot
    fig, ax = plt.subplots(figsize=(9, 6))

    # Scatter plot for each model
    # Enumerate through models and plot each one with a different color
    [[ax.scatter(elements, model, label=model.name, color=purps(idx)), print(idx)] for idx, model in enumerate([actual, model1, model2, model3, model4])]

    # Display legend only for the first plot
    if num == 1:
        ax.legend(loc='lower left')

    # Set the y-axis label
    ax.set_ylabel('Power Conversion Efficiency (%)')

    # Adjust layout for better appearance
    plt.tight_layout()

    # Save the plot as a PNG file
    fig.savefig('file{}.png'.format(num), dpi=500, format='png')

# Call the plot function for the first and second parts of the DataFrame
plot_it2(df1, 1)
plot_it2(df2, 2)
