import pandas as pd
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from pymatgen.core.composition import Composition
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
import random
import math

# Load your DataFrame (adjust the path accordingly)
df_materials = pd.read_csv('df_materials_updated.csv')

# Split data into features (X) and target variable (y)
X_train = df_materials.dropna().drop(['Compound_List', 'Dielectric_List'], axis=1)
y_train = df_materials.dropna()['Dielectric_List']

# Create a StandardScaler
scaler = StandardScaler()

# Scale the features
X_train_scaled = scaler.fit_transform(X_train)

# Create an SVR model
svm_model = SVR(kernel='poly', C=1000)  # You can experiment with different kernels and parameters

# Train the SVM model
svm_model.fit(X_train_scaled, y_train)

# Get user input for compound or elements
user_input = input("Enter 'compound' or 'elements': ")

# Initialize the dictionary with elements
elements_data = {
    'H': [0], 'He': [0], 'Li': [0], 'Be': [0], 'B': [0], 'C': [0], 'N': [0], 'O': [2], 'F': [0], 'Ne': [0],
    'Na': [0], 'Mg': [0], 'Al': [0], 'Si': [0], 'P': [0], 'S': [0], 'Cl': [0], 'Ar': [0], 'K': [0], 'Ca': [0],
    'Sc': [0], 'Ti': [1], 'V': [0], 'Cr': [0], 'Mn': [0], 'Fe': [0], 'Co': [0], 'Ni': [0], 'Cu': [0], 'Zn': [0],
    'Ga': [0], 'Ge': [0], 'As': [0], 'Se': [0], 'Br': [0], 'Kr': [0], 'Rb': [0], 'Sr': [0], 'Y': [0], 'Zr': [0],
    'Nb': [0], 'Mo': [0], 'Tc': [0], 'Ru': [0], 'Rh': [0], 'Pd': [0], 'Ag': [0], 'Cd': [0], 'In': [0], 'Sn': [0],
    'Sb': [0], 'Te': [0], 'I': [0], 'Xe': [0], 'Cs': [0], 'Ba': [0], 'La': [0], 'Ce': [0], 'Pr': [0], 'Nd': [0],
    'Pm': [0], 'Sm': [0], 'Eu': [0], 'Gd': [0], 'Tb': [0], 'Dy': [0], 'Ho': [0], 'Er': [0], 'Tm': [0], 'Yb': [0],
    'Lu': [0], 'Hf': [0], 'Ta': [0], 'W': [0], 'Re': [0], 'Os': [0], 'Ir': [0], 'Pt': [0], 'Au': [0], 'Hg': [0],
    'Tl': [0], 'Pb': [0], 'Bi': [0], 'Po': [0], 'At': [0], 'Rn': [0], 'Fr': [0], 'Ra': [0], 'Ac': [0], 'Th': [0],
    'Pa': [0], 'U': [0], 'Np': [0], 'Pu': [0], 'Am': [0], 'Cm': [0], 'Bk': [0], 'Cf': [0], 'Es': [0], 'Fm': [0],
    'Md': [0], 'No': [0], 'Lr': [0], 'Rf': [0], 'Db': [0], 'Sg': [0], 'Bh': [0], 'Hs': [0], 'Mt': [0], 'Ds': [0],
    'Rg': [0], 'Cn': [0], 'Nh': [0], 'Fl': [0], 'Mc': [0], 'Lv': [0], 'Ts': [0], 'Og': [0]
}

if user_input.lower() == 'compound':
    # Get user input for a compound
    compound_input = input("Enter a compound (e.g., H2O): ")
    prediction_input = compound_input
    
    # Parse the compound and update the dictionary with element counts
    for element, count in Composition(compound_input).get_el_amt_dict().items():
        elements_data[element][0] = count

elif user_input.lower() == 'elements':
    # Get user input for a list of elements
    elements_input = input("Enter a comma-separated list of elements: ")
    prediction_input = elements_input
    # Split the input string into a list
    elements_list = elements_input.split(',')
    
    # Update the dictionary with element counts
    for element in elements_list:
        if element in elements_data:
            elements_data[element][0] += 1

else:
    print("Invalid input. Please enter 'compound' or 'elements'.")

# Display the updated dictionary
# print("Updated Elements Data:")
# for element, value in elements_data.items():
#     print(f"{element}: {value}")

# Make predictions for Element+TiO2
element_tio2_data = pd.DataFrame(elements_data)
element_tio2_data_scaled = scaler.transform(element_tio2_data)

# Predict using the SVM model
prediction = svm_model.predict(element_tio2_data_scaled)

print(f"Predicted Absorbance Coefficient for {prediction_input} + TiO2: {prediction[0]}")

# Evaluate the SVM model
y_true = df_materials.dropna()['Dielectric_List']
y_pred = svm_model.predict(X_train_scaled)

# Calculate R-squared
r_squared = r2_score(y_true, y_pred)
# Calculate Mean Squared Error
mse = mean_squared_error(y_true, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"R-squared: {r_squared}")
