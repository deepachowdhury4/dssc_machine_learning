#analyzing data, make data frames and look at various kinds of materials

#understand DFT
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier  # For classification
from sklearn.ensemble import RandomForestRegressor  # For regression
import matplotlib.pyplot as plt
import warnings
from sklearn.metrics import accuracy_score
# warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore')

#Make data frame
official_df = pd.DataFrame(pd.read_csv('organized_real_data.csv'))

#Using 75-25 rules, 75% is training and 25% is testing data
#Training and Testing Data Complete
# Accuracy 
    # accuracy = accuracy_score(Y_test, y_pred)
    # print(f'Accuracy: {accuracy * 100:.2f}%')
accuracy_scores = []

for _ in range(100):
    train, test = train_test_split(official_df, test_size=0.25)

    #Divide features into training and testing data
    x_train_data= train[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
    y_train_data= train[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()
    x_test_data= test[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
    y_test_data= test[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()

    lists = [x_train_data, y_train_data, x_test_data, y_test_data]

    # Create an empty list to store the transformed DataFrames
    transformed_data = []

    total_columns_dataframe = []

    for data in lists:
        headers = data.columns.values.tolist()
        encoded_data = data.copy()  # Create a copy of the original data
        for column in headers:
            encoded_data = pd.get_dummies(encoded_data, columns=[column], prefix=[column])
            total_columns_dataframe.append(encoded_data.columns.values.tolist()) 
        # Append the transformed data to the list
        transformed_data.append(encoded_data)
    # The list 'transformed_data' now contains the transformed DataFrames
    # The DataFrame 'df' now contains the encoded data, it gets flattened for pre-processing
    flatten_list = [j for sub in total_columns_dataframe for j in sub]

    for j in flatten_list:
        for i in transformed_data:
            if j not in i.columns:
                # If 'j' is not found in the columns of DataFrame 'df'
                # Add a new column with all 0s and name it 'j'
                # i[j] = 0
                i[j] = np.repeat(0,len(i))



    #Initialize the Random Forest model
    rf_model = RandomForestClassifier()  # For classification
    # or
    #rf_model = RandomForestRegressor()  # For regression

    X_train =  transformed_data[0] #inputs: 'Photoanode', 'Photoanode_Fabrication_Process', 'Counter_Electrode', 'Counter_Electrode_Fabrication_Process', 'Modification_Type', 'Modification_Value', 'Dye', 'Electrolyte'
    Y_train =  transformed_data[1]  #outputs (PCE, 'VOC (V)', 'JSC (mA/cm2)', 'FF')
    X_test =  transformed_data[2]  #inputs: 'Photoanode', 'Photoanode_Fabrication_Process', 'Counter_Electrode', 'Counter_Electrode_Fabrication_Process', 'Modification_Type', 'Modification_Value', 'Dye', 'Electrolyte'
    Y_test =  transformed_data[3]  #outputs (PCE, 'VOC (V)', 'JSC (mA/cm2)', 'FF')

    # Create and fit a random forest model and evaluate accuracy 100 times
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train, Y_train)
    y_pred = rf_model.predict(X_test)
    accuracy = accuracy_score(Y_test, y_pred)
    accuracy_scores.append(accuracy*100)
    
# Plot the accuracy scores
plt.plot(range(1, 101), accuracy_scores, marker='o')
plt.xlabel('Iteration')
plt.ylabel('Accuracy (%)')
plt.title('Accuracy Over 100 Iterations')
plt.grid(True)
plt.show()


#Average Accuracy is: 73.27067669172935%