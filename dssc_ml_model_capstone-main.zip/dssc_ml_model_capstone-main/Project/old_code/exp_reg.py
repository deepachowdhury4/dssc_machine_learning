import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import math
import matplotlib.pyplot as plt
import warnings
import re
from statsmodels.tsa.holtwinters import ExponentialSmoothing
warnings.simplefilter(action='ignore')

#import dielectric coefficients into the ml model
import pandas as pd

# Replace 'your_file.csv' with the actual path to your CSV file
file_path = 'elements.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Extract columns 1 and 6 into two lists
column1_list = df.iloc[:, 0].tolist()  # Assuming the first column is at index 0
column6_list = df.iloc[:, 5].tolist()  # Assuming the sixth column is at index 5

# Display the lists
print("Column 1 as list:")
print(column1_list)

print("\nColumn 6 as list:")
print(column6_list)


# Generate some sample data
# Convert the list of strings to a list of floats
column6_list = [float(value) for value in column6_list]


new_column6_list = []
for i in column6_list:
    updated_column = ((2 * math.sqrt(2)) / (450e-9)) * i
    new_column6_list.append(updated_column)

X = new_column6_list
#PCE Calculation, assume FF = 0.5 (find it later)
ff = 0.5
q = 1.602e-19
phi = 10e17
L = 2.2361e-3
d = 5e-4
k = 1.381e-23
T = 300
m = 4.5
D = 2.3e-5
n_0 = 10e16
light_intensity = 10e17
# j_sc = ((q*phi*L*X)/(1-(L^2*X^2)))*(-L*X+np.tanh(d/L)+((L*X*np.exp(-d*X))/np.cosh(d/L)))
# v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
# y = (j_sc*v_oc*ff)/light_intensity

y_list = []
for i in new_column6_list:
    X_y = i
    j_sc = ((q*phi*L*X_y)/(1-(L**2*X_y**2)))*(-L*X_y+np.tanh(d/L)+((L*X_y*np.exp(-d*X_y))/np.cosh(d/L)))
    v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
    y = (j_sc*v_oc*ff)/light_intensity
    y_list.append(y)

y = y_list

# Create a DataFrame
df = pd.DataFrame({'X': X, 'y': y})

# Split the data into training and testing sets
train_size = int(len(df) * 0.8)
train, test = df.iloc[:train_size], df.iloc[train_size:]

# Initialize and train the exponential smoothing model
model = ExponentialSmoothing(train['y'], trend='add', seasonal='add', seasonal_periods=4)
fit_model = model.fit()

# Make predictions on the test set
y_pred = fit_model.predict(start=test.index[0], end=test.index[-1])

# Evaluate the model
mse = ((y_pred - test['y'])**2).mean()
print(f"Mean Squared Error: {mse}")

# Plot the results
plt.plot(train['X'], train['y'], label='Training Data')
plt.plot(test['X'], test['y'], label='Actual Test Data')
plt.plot(test['X'], y_pred, label='Predicted Test Data')
plt.title('Exponential Smoothing Model')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.show()