import pandas as pd
from mp_api.client import MPRester
from emmet.core.xas import Edge, XASDoc, Type
from emmet.core.summary import HasProps
import matplotlib as plt
from pymatgen.analysis.diffraction.core import DiffractionPattern
from pymatgen.analysis.diffraction.xrd import XRDCalculator
import pymatgen.analysis.solar.slme as solar
import warnings
import re
warnings.simplefilter(action='ignore')

mpr = MPRester("SCtRk3rApakiAaUerRgvlqbl9waADBCj")

file_path = 'elements.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Display the DataFrame (optional)
#print("Original DataFrame:")
#print(df)

# Convert columns 1 and 2 into lists
symbol_list = df.iloc[:, 0].tolist()  # Assuming the first column is column 1 (index 0)
elements_name_list = df.iloc[:, 1].tolist()  # Assuming the second column is column 2 (index 1)

# Display the lists (optional)
print("\nColumn 1 as list:")
print(symbol_list)

print("\nColumn 2 as list:")
print(elements_name_list)

# for i in symbol_list:
#     check_element = i
#     checker = mpr.summary.search( formula = check_element, has_props = [HasProps.dielectric], fields=["material_id"])
#     new_titanium_list = []
#     for i in range(len(checker)):
#         new_titanium_list.append(checker[i])
#         #print(str(checker[i]))
#         # Use regular expression to find the MPID
#         match = re.search(r"\((.*?)\)",  new_titanium_list[i])
#         # Check if the match is found
#         if match:
#             mpid = match.group(1)
#             print("Extracted MPID:", mpid)
#         else:
#             print("MPID not found in the input string.")


titanium_list = mpr.summary.search(
        formula = ['TiO2', '*TiO2', 'C', 'Ag', 'Zn', 'O', 'W', 'N', 'Ga', 'Cu', 'Fe' , 'Mg', 'B', 'Sn'], has_props = [HasProps.dielectric], fields=["material_id", "band_gap", 'bandstructure', 'elements', 'e_total']
    )
new_titanium_list = []
titanium_mpid = []
for i in range(len(titanium_list)):
    new_titanium_list.append(str(titanium_list[i]))
    #print(str(checker[i]))
    # Use regular expression to find the MPID
    match = re.search(r"\((.*?)\)",  new_titanium_list[i])
    # Check if the match is found
    if match:
        mpid = match.group(1)
        print("Extracted MPID:", mpid)
        titanium_mpid.append(mpid)
    else:
        print("MPID not found in the input string.")

# for i in titanium_mpid:
#     dielectric_doc = mpr.dielectric.search(material_ids=[i])
#     match = re.search(r"\((.*?)\)",  new_titanium_list[i])
#     # Check if the match is found
#     if match:
#         mpid = match.group(1)
#         print("Extracted MPID:", mpid)
#         titanium_mpid.append(mpid)
#     else:
#         print("MPID not found in the input string.")
#     print("MATERIL COMPLETE")


list = []
df = pd.DataFrame()
for i in titanium_mpid:
    df1 = pd.DataFrame()
    dielectric_doc = mpr.dielectric.search(material_ids=[i])
    df1 = pd.DataFrame(dielectric_doc)
    df = pd.concat([df, df1], ignore_index=True)

#Converting the TiO2 with dielectrics to a list of numbers (done by hand)
# column_23 = df.iloc[:, 23].tolist()
# column_23
#column_23_tio2 = [9.464398683333332, 63.21909958667055, 19.633245533381928, 8.703688133334309, 35.47354605768164 ]

dielectric_constant = [ 5.829713979999983, 6.598070946666667, 5.013771040000003, 1.5314598399999995, 1.4079819200000785, 1.3957247500000005,
9.520076496666668, 9.464398683333332, 63.21909958667055, 19.633245533381928, 8.703688133334309,
35.47354605768164]

#Do absorption coefficient calculations for everything (add dielectric to every tio2)


    

