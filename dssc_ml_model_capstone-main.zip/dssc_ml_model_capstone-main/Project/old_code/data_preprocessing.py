import pandas as pd
import pylab as pl
import numpy as np
import scipy.optimize as opt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split 
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn import ensemble
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV 
from sklearn.preprocessing import LabelEncoder
import pymc3 as pm


# read in excel file and convert into a dataframe object
df = pd.DataFrame(pd.read_excel("organized_data.xlsx"))

# Arrays; all empty cells are nan values
photoanode_array = df['Photoanode'].values
photoanode_fab_process_array = df['Photoanode_Fabrication_Process'].values
counter_electrode_array = df['Counter_Electrode'].values
counter_electrode_fab_process_array = df['Counter_Electrode_Fabrication_Process'].values
modification_type_array = df['Modification_Type'].values
modification_value_array = [str(value) for value in df['Modification_Value'].values] # All values must be same for encoder
dye_array = df['Dye'].values
electrolyte_array = df['Electrolyte'].values
voltage_open_circuit_array = df['VOC (V)'].values
short_circuit_current_density_array = df['JSC (mA/cm2)'].values
fill_factor_array = df['FF'].values
power_conversion_efficiency_array = df['PCE (%)'].values

#Label Encoding

# Create a LabelEncoder instance
label_encoder = LabelEncoder()

# Fit the encoder to your categorical data and transform it
photoanode_array_data = label_encoder.fit_transform(photoanode_array)
photoanode_fab_process_array_data = label_encoder.fit_transform(photoanode_fab_process_array)
counter_electrode_array_data = label_encoder.fit_transform(counter_electrode_array)
counter_electrode_fab_process_array_data = label_encoder.fit_transform(counter_electrode_fab_process_array)
modification_type_array_data = label_encoder.fit_transform(modification_type_array)
modification_value_array_data = label_encoder.fit_transform(modification_value_array) #causing problems?
dye_array_data = label_encoder.fit_transform(dye_array)
electrolyte_array_data = label_encoder.fit_transform(electrolyte_array)
voltage_open_circuit_array_data = label_encoder.fit_transform(voltage_open_circuit_array)
short_circuit_current_density_array_data = label_encoder.fit_transform(short_circuit_current_density_array)
fill_factor_array_data = label_encoder.fit_transform(fill_factor_array)
power_conversion_efficiency_array_data = label_encoder.fit_transform(power_conversion_efficiency_array)

print(power_conversion_efficiency_array_data) #checked if encoding was done correctly :)
print('')

#MCMC
import torch
import pyro
import pyro.distributions as dist

# Define a simple Bayesian model
def model(data):
    prior_mean = torch.tensor(0.0)
    prior_std = torch.tensor(1.0)
    parameter = pyro.sample("parameter", dist.Normal(prior_mean, prior_std))
    likelihood = pyro.sample("likelihood", dist.Normal(parameter, 0.1), obs=data)

# Perform MCMC using Pyro (a PyTorch-based probabilistic programming library)
import pyro.infer
import pyro.optim

data = torch.tensor(10)
nuts_kernel = pyro.infer.NUTS(model)
mcmc = pyro.infer.MCMC(nuts_kernel, num_samples=1000, num_chains=1)
mcmc.run(data)

# Analyze the results
samples = mcmc.get_samples()

#import matplotlib.pyplot as plt

# Create a histogram to visualize the distribution
plt.hist(samples, bins=30, density=True, alpha=0.5, color='b', label='MCMC Samples')

# You can also add labels, titles, and other plot customizations
plt.xlabel('Value')
plt.ylabel('Probability Density')
plt.title('MCMC Sample Distribution')
plt.legend()

# Display the plot
plt.show()


#print(samples)



#find backup data



