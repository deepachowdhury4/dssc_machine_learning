import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_selection import RFE
from sklearn.metrics import accuracy_score
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.feature_selection import SelectKBest, chi2
import warnings
import seaborn as sns
warnings.simplefilter(action='ignore')



official_df = pd.DataFrame(pd.read_csv('official_fake_data.csv'))

accuracy_scores = []
for _ in range(100):
    #Using 75-25 rules, 75% is training and 25% is testing data
    #Training and Testing Data Complete
    train, test = train_test_split(official_df, test_size=0.25)

    x_train_data= train[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
    y_train_data= train[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()
    x_test_data= test[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
    y_test_data= test[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()

    lists = [x_train_data, y_train_data, x_test_data, y_test_data]

    # Create an empty list to store the transformed DataFrames
    transformed_data = []

    total_columns_dataframe = []

    for data in lists:
        headers = data.columns.values.tolist()
        encoded_data = data.copy()  # Create a copy of the original data
        for column in headers:
            encoded_data = pd.get_dummies(encoded_data, columns=[column], prefix=[column])
            total_columns_dataframe.append(encoded_data.columns.values.tolist()) 
        # Append the transformed data to the list
        transformed_data.append(encoded_data)

    # The list 'transformed_data' now contains the transformed DataFrames
    # The DataFrame 'df' now contains the encoded data
    #print(official_df)

    flatten_list = [j for sub in total_columns_dataframe for j in sub]

    for j in flatten_list:
        for i in transformed_data:
            if j not in i.columns:
                # If 'j' is not found in the columns of DataFrame 'df'
                # Add a new column with all 0s and name it 'j'
                # i[j] = 0
                i[j] = np.repeat(0,len(i))

    knn = KNeighborsClassifier(n_neighbors=6)

    X_train = transformed_data[0]
    Y_train = transformed_data[1]
    X_test = transformed_data[2]
    Y_test = transformed_data[3]

    selector = SelectKBest(score_func=chi2, k=5)
    X_train_selected = selector.fit_transform(X_train, Y_train)
    X_test_selected = selector.transform(X_test)
    feature_ranking = selector.scores_

    knn.fit(X_train_selected, Y_train)

    # Make predictions and calculate accuracy
    y_pred = knn.predict(X_test_selected)
    accuracy = accuracy_score(Y_test, y_pred)
    print(f'Accuracy with feature selection: {accuracy * 100:.2f}%')
    accuracy_scores.append(accuracy)

    # # Define the folder path where you want to save the plot
    # folder_path = './plots/plots_importance_knn/'

    # # Specify the filename and format (e.g., PNG, PDF, etc.)
    # file_name = 'iteration_'+str(_+1)+'_real.png'

    # # Combine the folder path and filename
    # save_path = folder_path + file_name

    # # Save the plot to the specified folder
    # plt.savefig(save_path)

correlation_matrix = official_df.corr()
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm")
plt.show()

# Plot the accuracy scores
plt.plot(range(1, 101), accuracy_scores, marker='o', color = 'orange')
plt.xlabel('Iteration')
plt.ylabel('Accuracy (%)')
plt.title('Accuracy Over 100 Iterations: KNN Feature Selection')
plt.grid(True)
plt.show()



