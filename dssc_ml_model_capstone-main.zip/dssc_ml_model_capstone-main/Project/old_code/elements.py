import csv

# Original lists of elements
transition_metals = ["Scandium (Sc)", "Titanium (Ti)", "Vanadium (V)", "Chromium (Cr)", "Manganese (Mn)", "Iron (Fe)", "Cobalt (Co)", "Nickel (Ni)", "Copper (Cu)", "Zinc (Zn)"]
rare_earth_metals = ["Lanthanum (La)", "Cerium (Ce)", "Praseodymium (Pr)", "Neodymium (Nd)", "Promethium (Pm)", "Samarium (Sm)", "Europium (Eu)", "Gadolinium (Gd)", "Terbium (Tb)", "Dysprosium (Dy)", "Holmium (Ho)", "Erbium (Er)", "Thulium (Tm)", "Ytterbium (Yb)", "Lutetium (Lu)"]

# Function to split element names into atomic symbol and full name
def split_element_name(element_name):
    parts = element_name.split(" (")
    if len(parts) == 2:
        symbol = parts[1][0:-1]  # Remove the closing parenthesis
        full_name = parts[0]
        return symbol, full_name
    else:
        return None, element_name

# Process transition metals
split_transition_metals = [(symbol, full_name, "Transition_Metal") for symbol, full_name in (split_element_name(element) for element in transition_metals)]

# Process rare earth metals
split_rare_earth_metals = [(symbol, full_name, "Rare_Earth_Metal") for symbol, full_name in (split_element_name(element) for element in rare_earth_metals)]

# Combine the lists
combined_data = split_transition_metals + split_rare_earth_metals

# Write the data to a CSV file
with open("elements.csv", "w", newline="") as csvfile:
    csv_writer = csv.writer(csvfile)
    csv_writer.writerow(["Symbol", "Full Name", "Type"])
    csv_writer.writerows(combined_data)

#print("Elements Written to elements.csv file Correctly")