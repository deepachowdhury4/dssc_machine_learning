import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier  # For classification
from sklearn.ensemble import RandomForestRegressor  # For regression
import matplotlib.pyplot as plt
import warnings
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix, multilabel_confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
warnings.simplefilter(action='ignore')

#Import Data into Dataframe
official_df = pd.DataFrame(pd.read_csv('organized_real_data.csv'))

#For Real Data, there seems to be excess names columns, removed through
# this line of code. 
official_df = official_df.iloc[:141, :12]


#Using 75-25 rules, 75% is training and 25% is testing data
#Training and Testing Data Complete
train, test = train_test_split(official_df, test_size=0.25)

#Divide the training data and testing data into its input and output variables, resulting in four datasets
# Input Variables: 'Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte'
# Output Variables: 'VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)', what results are based on specific configurations
x_train_data= train[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
y_train_data= train[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()
x_test_data= test[['Photoanode', 'PA_Fabrication_Process', 'Counter_Electrode', 'CE_Fabrication_Process', 'Modification_Type', 'Value_Mod', 'Dye', 'Electrolyte']].copy()
y_test_data= test[['VOC_(V)','JSC_(mA/cm2)','FF','PCE_(percent)']].copy()

#Store all the data above (x_train_data, y_train_data, x_test_data, x_train_data) into a list for encoding
lists = [x_train_data, y_train_data, x_test_data, y_test_data]

# Create an empty list to store the transformed DataFrames
transformed_data = []
#Count the number of columns for each dataframe (x_train_data, y_train_data, x_test_data, x_train_data) 
total_columns_dataframe = []

# Iterate through each DataFrame in the 'lists' and apply one-hot encoding
for data in lists:
    # Get the column headers of the current DataFrame
    headers = data.columns.values.tolist()
    # Create a copy of the original data to avoid modifying it directly
    encoded_data = data.copy() 
    # Iterate through each column and perform one-hot encoding
    for column in headers:
        encoded_data = pd.get_dummies(encoded_data, columns=[column], prefix=[column])
        total_columns_dataframe.append(encoded_data.columns.values.tolist()) 
    # Append the transformed data to the list
    transformed_data.append(encoded_data)
# The list 'transformed_data' now contains the transformed DataFrames
# The DataFrame 'df' now contains the encoded data
#print(official_df)

flatten_list = [j for sub in total_columns_dataframe for j in sub]

for j in flatten_list:
    for i in transformed_data:
        if j not in i.columns:
            # If 'j' is not found in the columns of DataFrame 'df'
            # Add a new column with all 0s and name it 'j'
            # i[j] = 0
            i[j] = np.repeat(0,len(i))


X_train =  transformed_data[0] #inputs: 'Photoanode', 'Photoanode_Fabrication_Process', 'Counter_Electrode', 'Counter_Electrode_Fabrication_Process', 'Modification_Type', 'Modification_Value', 'Dye', 'Electrolyte'
Y_train =  transformed_data[1]  #outputs (PCE, 'VOC (V)', 'JSC (mA/cm2)', 'FF')
X_test =  transformed_data[2]  #inputs: 'Photoanode', 'Photoanode_Fabrication_Process', 'Counter_Electrode', 'Counter_Electrode_Fabrication_Process', 'Modification_Type', 'Modification_Value', 'Dye', 'Electrolyte'
Y_test =  transformed_data[3]  #outputs (PCE, 'VOC (V)', 'JSC (mA/cm2)', 'FF')

# Create and fit a Random Forest classifier, random_state = 42 means a shuffled dataset
rf = RandomForestClassifier(n_estimators=100, random_state=42) # For classification
rf.fit(X_train, Y_train)
y_pred = rf.predict(X_test)

# Create and fit a random forest model 
feature_importances = rf.feature_importances_

# Sort features by importance
sorted_indices = np.argsort(feature_importances)[::-1]

# Print feature names and their importances
x_train_columns_plot = []
feature_importances_plot = []
for i in sorted_indices:
    # print(f"Feature: {X_train.columns[i]}, Importance: {feature_importances[i]}")
    x_train_columns_plot.append(X_train.columns[i])
    feature_importances_plot.append(feature_importances[i])

count = 0

importances_count_dict = dict(zip(list(official_df.columns[0:-2]),
                                np.repeat(0,len(official_df.columns[0:-2]))))
importances_sum_dict = dict(zip(list(official_df.columns[0:-2]),
                                np.repeat(0,len(official_df.columns[0:-2]))))

for variable_name in official_df.columns[0:-2]:
    for i,column_name in enumerate(x_train_columns_plot):
        if variable_name in column_name :
            # Add one for each instance of the variable name found
            importances_count_dict[variable_name] += 1 
            importances_sum_dict[variable_name] += feature_importances[i]
        else:
            pass
    
importances_plot_dict = dict(zip(list(official_df.columns[0:-2]), np.repeat(0,len(official_df.columns[0:-2]))))
for variable_name in official_df.columns[0:-2]:
    importances_plot_dict[variable_name] = importances_sum_dict[variable_name]/importances_count_dict[variable_name]

importances_plot_dict = {x:y*100 for x,y in importances_plot_dict.items() if y!=0}

# # plot will show all 12 feature importances vs numeric value
# fig1,ax1 = plt.subplots()
# # plt.figure(figsize=(10, 6))
# plt.bar(list(importances_plot_dict.keys()),list(importances_plot_dict.values()),
#         color= "#800080", edgecolor = 'black')
# plt.ylabel('Feature Importances (%)')
# plt.xlabel('Input Feature Name')
# plt.title('Input Feature Importance for Data')
# plt.xticks(rotation=30)
# plt.tight_layout()
#plt.show()

# # Define the folder path where you want to save the plot
# folder_path = './plots_importance/'

# # Specify the filename and format (e.g., PNG, PDF, etc.)
# file_name = 'iteration_'+str(_+1)+'_real.png'

# # Combine the folder path and filename
# save_path = folder_path + file_name

# # Save the plot to the specified folder
# plt.savefig(save_path)

# Plot a confusion matrix for each label
# y_pred_1 = pd.DataFrame(y_pred)
# for i in range(len(y_pred_1.columns.values)):
#     #y_pred_1.columns.values[i] = Y_test.columns.values[i]
#     y_pred_1.rename(columns = {y_pred_1.columns.values[i] :Y_test.columns.values[i]}, inplace = True)

y_pred_1 = pd.DataFrame(feature_importances).T
for i in range(len(y_pred_1.columns.values)):
    #y_pred_1.columns.values[i] = Y_test.columns.values[i]
    y_pred_1.rename(columns = {y_pred_1.columns.values[i] :Y_test.columns.values[i]}, inplace = True)

# def my_function(dataframe_var):
#   df = pd.DataFrame(dataframe_var)
#   # Extract common parts of column names and create new columns
#   new_columns = {}
#   for column in df.columns:
#     # Convert the column name to a string before splitting
#     column_name = str(column)
#   # Split the column name by '_' and take the first part
#     category = column_name.split('_')[0]
#     if category not in new_columns:
#         new_columns[category] = df[column]
#     else:
#         new_columns[category] += df[column]
#   # Create a new DataFrame with the combined columns
#   new_df = pd.DataFrame(new_columns)
#   # Renaming the columns (optional)
#   new_df.columns = new_df.columns.str.replace(r'_[0-50. %°]+', '')
#   return new_df

# # Display the new DataFrame
# Y_test_edit = my_function(Y_test)
# y_pred_edit = my_function(y_pred_1)

# z = multilabel_confusion_matrix(Y_test_edit, y_pred_edit)

# for i in range(len(Y_test_edit.columns)): 
#     plt.figure(figsize=(6, 4))
#     sns.heatmap(z[i], annot=True, fmt='d', cmap='Blues')
#     plt.xlabel('Predicted')
#     plt.ylabel('Actual')
#     plt.title(f'Confusion Matrix for {Y_test_edit.columns[i]}')
#     plt.show()


#Correlation Matrix for Model
correlation_matrix = official_df.corr()
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm")
plt.show()