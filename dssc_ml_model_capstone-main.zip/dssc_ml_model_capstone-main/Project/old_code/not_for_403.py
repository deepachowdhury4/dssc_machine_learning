
string_list = []
wl = []
import cmath
reflectivity = []
n_m = 1.5126

for num in range(400, 1010, 10):
    x = num/1000
    # Convert the number to a string and append it to the list
    n=((2.2705778-0.010059376*x**2+0.010414999*x**-2+0.00028872517*x**-4-2.2214495e-05*x**-6+1.4258559e-06*x**-8)**.5).real
    string_list.append(n)
    wl.append(num)
    reflect = abs((n-n_m**2)/(n+n_m**2))**2
    reflectivity.append(reflect)


import csv


csv_file_path = "string_list.csv"

# Open the CSV file for writing
with open(csv_file_path, 'w', newline='') as csv_file:
    writer = csv.writer(csv_file)

    # Write the list to the CSV file
    writer.writerow(string_list)
    writer.writerow(wl)
    writer.writerow(reflectivity)

print(f"The list has been saved to {csv_file_path}")