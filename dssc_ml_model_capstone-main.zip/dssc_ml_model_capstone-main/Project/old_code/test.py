# import pandas as pd
# from sklearn.preprocessing import LabelEncoder

# # Create a sample DataFrame
# data = {
#     'Color': ['Red', 'Green', 'Blue', 'Red', 'Green'],
#     'Shape': ['Circle', 'Triangle', 'Square', 'Circle', 'Square'],
#     'Size': ['Small', 'Large', 'Medium', 'Medium', 'Small']
# }

# official_df = pd.DataFrame(data)

# # Identify columns with string values that need encoding
# columns_to_encode = ['Color', 'Shape', 'Size']


# # Fit the encoder to your categorical data and transform it
# from sklearn.preprocessing import LabelEncoder
# for data in columns_to_encode:
#     headers = data.columns. values.tolist() 
#     # Apply different encoding methods to each column
#     for column in headers:
#         if len(data[column].unique()) <= 3:
#             # If the number of unique values is small, use label encoding
#             label_encoder = LabelEncoder()
#             data[column] = label_encoder.fit_transform(data[column])
#         else:
#             # If there are many unique values, consider other encoding methods like one-hot encoding
#             data= pd.get_dummies(data, columns=[column], prefix=[column])
#     #print(headers)

#     # The DataFrame 'df' now contains the encoded data
#     #print(official_df)

# create a list
prime_numbers = [2, 3, 5, 7, 9, 11, 12, 9]

# remove 9 from the list
prime_numbers.remove(9)


# Updated prime_numbers List
print('Updated List: ', prime_numbers)

# Output: Updated List:  [2, 3, 5, 7, 11]