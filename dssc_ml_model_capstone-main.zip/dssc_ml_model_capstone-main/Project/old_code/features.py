import pandas as pd
from mp_api.client import MPRester
from emmet.core.xas import Edge, XASDoc, Type
from emmet.core.summary import HasProps
import matplotlib as plt
from pymatgen.analysis.diffraction.core import DiffractionPattern
from pymatgen.analysis.diffraction.xrd import XRDCalculator
import pymatgen.analysis.solar.slme as solar
import warnings
warnings.simplefilter(action='ignore')

mpr = MPRester("SCtRk3rApakiAaUerRgvlqbl9waADBCj")
doped_tio2= mpr.summary.search( formula = '*TiO2', fields=["material_id", "absorption", "structure", "total", "symmetry"])
tio2 = mpr.summary.search( formula = 'TiO2', fields=["material_id", "absorption"])

final = doped_tio2 + tio2

xas = mpr.xas.search_xas_docs(formula = "TiO2", absorbing_element = 'Ti', edge = Edge.K)

material_id = 'mp-1234'

    # Retrieve the entry for the material, including dielectric data
from mp_api.client import MPRester
from emmet.core.summary import HasProps


dielectric_doc = mpr.dielectric.search(material_ids=["mp-554278"])

mpids = [doc.material_id for doc in dielectric_doc]

df = pd.DataFrame(dielectric_doc)
    # Access dielectric data from the entry
#dielectric_data = entry.data.get('dielectric', None)
# IT's UNDER TOTAL YAY!\
x = ((31.295906947443044, 2.65831531596474e-06, 1.8324174460178337), 
     (2.6583153159647428e-06, 38.90446308304492, 1.556479372880653e-07), 
     (1.8324135860178337, 1.5564760941461302e-07, 36.22026814255696))
y = ((1,0,0), (2,5,0), (3,5,6))
absorption_coeff = solar.absorption_coefficient(x)

tio2 = mpr.summary.search( formula = 'TiO2', has_props = [HasProps.dielectric], fields=["material_id", "absorption"])

