
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import math
import matplotlib.pyplot as plt
import warnings
import re
from scipy.integrate import simps
warnings.simplefilter(action='ignore')

#import dielectric coefficients into the ml model
import pandas as pd

file_path = 'elements.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Extract columns 1 and 6 into two lists
column1_list = df.iloc[:, 0].tolist()  # Assuming the first column is at index 0
column6_list = df.iloc[:, 5].tolist()  # Assuming the sixth column is at index 5

# Display the lists
print("Column 1 as list:")
print(column1_list)

print("\nColumn 6 as list:")
print(column6_list)


# Generate some sample data
# Convert the list of strings to a list of floats
column6_list = [float(value) for value in column6_list]


new_column6_list = []
for i in column6_list:
    updated_column = ((2 * math.sqrt(2)) / (450e-9)) * i
    new_column6_list.append(updated_column)

X = new_column6_list
#PCE Calculation, assume FF = 0.5 (find it later)
ff = 0.65
q = 1.602e-19
phi = 10e17
L = 2.2361e-3
d = 5e-4
k = 1.381e-23
T = 300
m = 4.5
D = 2.3e-5
n_0 = 10e16
light_intensity = 10e17
# j_sc = ((q*phi*L*X)/(1-(L^2*X^2)))*(-L*X+np.tanh(d/L)+((L*X*np.exp(-d*X))/np.cosh(d/L)))
# v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
# y = (j_sc*v_oc*ff)/light_intensity

y_list = []
j_sc_list = []
v_oc_list = []
for i in new_column6_list:
    X_y = i
    j_sc = ((q*phi*L*X_y)/(1-(L**2*X_y**2)))*(-L*X_y+np.tanh(d/L)+((L*X_y*np.exp(-d*X_y))/np.cosh(d/L)))
    j_sc_list.append(j_sc)
    v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
    v_oc_list.append(v_oc)
    y = (j_sc*v_oc*ff)/light_intensity
    y_list.append(math.exp(y))
    #y_list.append((y))

pce = y_list

import numpy as np
import matplotlib.pyplot as plt

# Constants
q = 1.6e-19  # Elementary charge (C)
phi = 10e15  # Phi value
L = 2.2361e-5  # L value
d = 5e-6  # d value
temp = 300

# Generate X_y values from 0 to 0.75 V in increments of 0.001
X_y_values = np.arange(0, 0.751, 0.0001)

# Calculate j_sc for each X_y value using the given equation
j_sc = j_sc_list[36]

#Plot I-V Curve for 
j = j_sc-((q*D*n_0/L)*np.tanh(d/L))*(np.exp((q*X_y_values)/(k*temp*m))-1)
# Plot the results
plt.scatter(X_y_values, j+2.5, label='I-V Curve')
plt.title('Current Density vs Voltage')
plt.xlabel('Voltage (V)')
plt.ylabel('Current Density (mA/cm^2)')
plt.legend()
plt.grid(True)
plt.show()

# Initialize variables to store the maximum area and corresponding x, y values
max_area = 0
max_x = 0
max_y = 0

# Iterate through different intervals
for i in range(1, len(X_y_values)):
    # Calculate the current density for the current interval
    j_interval = j[:i]

    # Calculate the area under the curve for the current interval
    area = simps(j_interval, X_y_values[:i])

    # Update the maximum area and corresponding x, y values if the current area is greater
    if area > max_area:
        max_area = area
        max_x = X_y_values[i - 1]
        max_y = np.max(j_interval)

# Print the values that result in the maximum area
print(f"Maximum Area under the curve: {max_area:.2f} mA/cm^2")
print(f"Corresponding X value: {max_x:.2f}")
print(f"Corresponding Y value: {max_y:.2f} mA/cm^2")


pce = (max_x*max_y)/light_intensity
print('PCE: ', pce*10e17)