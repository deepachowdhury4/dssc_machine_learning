import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import math
from sklearn.metrics import r2_score

#import dielectric coefficients into the ml model
import pandas as pd

# Replace 'your_file.csv' with the actual path to your CSV file
file_path = 'elements.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Extract columns 1 and 6 into two lists
column1_list = df.iloc[:, 0].tolist()  # Assuming the first column is at index 0
column6_list = df.iloc[:, 5].tolist()  # Assuming the sixth column is at index 5

# Display the lists
# print("Column 1 as list:")
# print(column1_list)

# print("\nColumn 6 as list:")
# print(column6_list)


# Generate some sample data
# Convert the list of strings to a list of floats
column6_list = [float(value) for value in column6_list]


new_column6_list = []
for i in column6_list:
    updated_column = ((2 * math.sqrt(2)) / (450e-9)) * i
    new_column6_list.append(updated_column)

X = new_column6_list
#PCE Calculation, assume FF = 0.5 (find it later)
ff = 0.5
q = 1.602e-19
phi = 10e17
L = 2.2361e-3
d = 5e-4
k = 1.381e-23
T = 300
m = 4.5
D = 2.3e-5
n_0 = 10e16
light_intensity = 10e17
# j_sc = ((q*phi*L*X)/(1-(L^2*X^2)))*(-L*X+np.tanh(d/L)+((L*X*np.exp(-d*X))/np.cosh(d/L)))
# v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
# y = (j_sc*v_oc*ff)/light_intensity

y_list = []
for i in new_column6_list:
    X_y = i
    j_sc = ((q*phi*L*X_y)/(1-(L**2*X_y**2)))*(-L*X_y+np.tanh(d/L)+((L*X_y*np.exp(-d*X_y))/np.cosh(d/L)))
    v_oc = ((k*T*m)/(q))*math.log(((L*j_sc)/(q*D*n_0*np.tanh(d/L)))+1)
    y = (j_sc*v_oc*ff)/light_intensity
    #y_list.append(math.exp(y))
    y_list.append((y))

y = y_list

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Assuming X_train and X_test are lists
X_train = np.array(X_train).reshape(-1, 1)
X_test = np.array(X_test).reshape(-1, 1)

# Create a k-Nearest Neighbors Regressor with k=3
knn_model = KNeighborsRegressor(n_neighbors=3)

# Train the model on the training data
knn_model.fit(X_train, y_train)

# Make predictions on the test data
y_pred = knn_model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

# Calculate R-squared
r_squared = r2_score(y_test, y_pred)
print(f"R-squared: {r_squared}")

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
#DO THIS AFTER DEMO
# # Assuming y_true and y_pred are your true and predicted values, respectively
# mae = mean_absolute_error(y_true, y_pred)
# mse = mean_squared_error(y_true, y_pred)
# rmse = mean_squared_error(y_true, y_pred, squared=False)  # Pass squared=False to get RMSE
# r2 = r2_score(y_true, y_pred)

# print("MAE:", mae)
# print("MSE:", mse)
# print("RMSE:", rmse)
# print("R-squared:", r2)


# Plot the results
plt.scatter(X_test, y_test, color='black', label='Actual Data')
plt.scatter(X_test, y_pred, color='red', label='Predicted Data')
plt.title('KNN Regression Model')
plt.xlabel('Absorption Coefficient')
plt.ylabel('PCE Predictions')
plt.legend()
plt.show()




# Two inputs: add absorbance together and then input into this equation
number = 0 
# Convert inputs to integers
input1 = str(input("Enter the Element: "))

if input1 in column1_list:
    #Find the constant associated witht it
    index_column5 = column1_list.index(input1)
else:
    print("Error, element not found, please reinput")
    input1 = str(input("Enter the Element"))
    if input1 in column1_list:
        #Find the constant associated witht it
        index_column5 = column1_list.index(input1)

found_delectric = column6_list[index_column5]
ti_o2_dielectric = 9.464398683

# Perform some operation with the integers
result = found_delectric + ti_o2_dielectric

abs_calc = float(((2*math.sqrt(2))/(450e-9))*result) #absorbance coefficient

# Function to predict a single input value
def predict_single_input(input_value):
    input_array = np.array([[input_value]])
    prediction = knn_model.predict(input_array)
    return prediction[0]

# User input for prediction

# Make prediction using the model
prediction = predict_single_input(abs_calc)

print(f"The predicted output for {input1} is: {predict_single_input}")