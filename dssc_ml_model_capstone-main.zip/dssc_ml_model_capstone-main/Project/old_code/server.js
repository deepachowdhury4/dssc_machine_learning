const express = require('express');
const app = express();
const port = 3000; // You can change the port if needed

app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/generate', (req, res) => {
  const input1 = req.body.input1;
  const input2 = req.body.input2;

  // Generate the HTML response with the input values
  const outputHTML = `<p>${input1} ${input2}</p>`;
  
  res.send(outputHTML);
});

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
