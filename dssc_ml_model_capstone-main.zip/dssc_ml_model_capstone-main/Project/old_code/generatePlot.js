const fs = require('fs');
const csv = require('csv-parser');

const dataX = []; // Array to store data from column 1
const dataY = []; // Array to store data from column 2

fs.createReadStream('your_csv_file.csv')
  .pipe(csv())
  .on('data', (row) => {
    // Replace 'column1' and 'column2' with the actual column names in your CSV.
    dataX.push(row['column1']);
    dataY.push(row['column2']);
  })
  .on('end', () => {
    // Call a function to generate the plot using dataX and dataY
    generatePlot(dataX, dataY);
  });
